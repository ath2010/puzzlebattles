$(function() {
tourended=false;
tourstarted=false;
var timer;
var $join = $('#join'); 
var $leave = $('#active');
$join.hide();
$leave.hide();
 //socket
var socket;
var loginuser; 
socket = io("https://puzzlebattles.herokuapp.com");  
   
if (localStorage.getItem("loginname")===null) {
    var url = document.URL;
    loginuser = url.substring(url.indexOf("=")+1, url.indexOf("&"));
	localStorage.setItem("loginname",loginuser);
} else {
    loginuser=localStorage.getItem("loginname");
}

if(loginuser && loginuser!==null){
 connected = true;
 socket.emit('get tour',loginuser);
 var user = document.getElementById('user');
 var username = document.getElementById('username');
 username.innerHTML = localStorage.getItem("loginname");
 var group = document.createElement('div');  
user.appendChild(group)
group.innerHTML= "<div role=" +"group" +">"+ "<a href=" + "https://www.learnmyskills.com/user/" + loginuser+ ">profile</a>"+"<a href=" + "https://www.learnmyskills.com/puzzle-dashboard"+ ">logout</a></div>";
} else {
 window.location.href ="https://www.learnmyskills.com/loginwithlichess";
}

  //load chat message elements
   var messages = document.getElementById('messages');
   var form = document.getElementById('form');
   var input = document.getElementById('input');

  //chat message 
  form.addEventListener('submit', function(e) {
        e.preventDefault();
        if (input.value) {
          sendMessage({
        username: loginuser,
        message: input.value
      });
          input.value = '';
  }
 });


 //Sends a chat message to server
  function sendMessage (msg) {
    // Prevent markup from being injected into the message
    // if there is a non-empty message and a socket connection
    if (msg && connected) {
      // tell server to execute 'new message' and send along one parameter
      socket.emit('chat message',JSON.stringify(msg));
		
    }
  }

function scrollToBottom() {
  messages.scrollTop = messages.scrollHeight;
}


//messages from server:
 socket.on('chat message', function(msg) {
	  var servermessage=JSON.parse(msg);
      var item = document.createElement('li');       
		var user = document.createElement('a');  
		user.className = "user-link";
		var text = document.createElement('t');  
		 user.textContent =servermessage.username;
		  text.textContent = " "+servermessage.message;
          item.appendChild(user);
		  item.appendChild(text);
        messages.appendChild(item);
		scrollToBottom();
 });

function printchatmsg(msg){
for (var i=0;i<msg.length;i++)
         {
		 var item = document.createElement('li');       
		var user = document.createElement('a');  
		user.className = "user-link";
		var text = document.createElement('t');  
		 user.textContent =msg[i].username;
		  text.textContent = " "+msg[i].message;
          item.appendChild(user);
		  item.appendChild(text);
          messages.appendChild(item);

         }
		 scrollToBottom();
    }

//messages from server:
 socket.on('mod message', function(msg) {
        var item = document.createElement('li');       
		var user = document.createElement('a');  
		user.className = "user-link";
		var text = document.createElement('t');  
		 user.textContent ="Mod";
		  text.textContent = " "+msg;
          item.appendChild(user);
		  item.appendChild(text);
        messages.appendChild(item);
  });

//messages from server:
 socket.on('live users', function(liveusers) {
	  $("#spectators").html("");
    $.each(liveusers, function(index, value){
            $("#spectators").append( value +"," );
        });
  $("#spectators").append("moderator");
   });

//Response from Server on existing User found in a game
socket.on('alreadyJoined', function (data) {
$('#usermsg').html('You have alreay attempted. Only one attempt allowed');
});


//Response from Server on existing User found in a game
socket.on('init-user', function (data) {
   var data=JSON.parse(data);
   settimer(data.tourtime);
   printchatmsg(data.msg);
   setTimeout(function(){ if(!tourended){ if(loginuser===data.username){addLeavCtrl(); } else{addJoinCtrl(); } } } , 3000);
  updateUserList(data.users);
 });



socket.on('user added', function (username) {
 if(loginuser===username){
 addLeavCtrl();
   } 
});


socket.on('update users', function (data) {
  var data=JSON.parse(data);
 updateUserList(data.users)
});

socket.on('update scores', function (data) {
  var data=JSON.parse(data);
// renderUserList(data,"score")
});

socket.on('user left', function (data) {
 var data=JSON.parse(data);
 if(loginuser===data.username){
    addJoinCtrl();
   } 
   updateUserList(data.users);
});


socket.on('start game', function (data) {
$('#usermsg').html('<div class="success message"><h3> Puzzle Rush will start in few seconds</h3></div>');
localStorage.setItem('loginname',loginuser);
localStorage.setItem('start','start');
setTimeout( ()=>{  console.log("game started");
window.location.href ="https://www.learnmyskills.com/dailypuzzlerush.html"
  }	,5000);	
  });


socket.on('info message', function (data) {
$('#usermsg').html('<div class="error message"><h3> Already attempted</h3></div>');
setTimeout( ()=>{  $('#usermsg').html(" ") }	,10000);
 });

   $join.click(function () {
  if(loginuser){
    socket.emit('add user',loginuser);
   }
  })

$leave.click(function () {
 if(loginuser && !tourstarted){
    socket.emit('user left',loginuser);
 } else if (!tourended){
    $leave.hide()
	$join.html("Start");
    $join.show();
 }
 })


         
function addLeavCtrl(){
   $join.hide();
    $leave.show();
 };

function addJoinCtrl(){
    $leave.hide();
    $join.show();

};


//utility functions
  function userExists(array, n) {
    const index = array.indexOf(n);

    // if the element is in the array, remove it
    if(index > -1) {

       return true 
    }
    return false;
}

var timer;
function settimer(tour)
{
	var tourtime =tour;
 clearInterval(timer);
 var end = tour.start; // Arrange values in Date Time Format
 var second = 1000; // Total Millisecond In One Sec
 var minute = second * 60; // Total Sec In One Min
 var hour = minute * 60; // Total Min In One Hour
 var day = hour * 24; // Total Hour In One Day

 function showtimer() {
  var now = new Date().getTime();
  var remain = end - now; // Get The Difference Between Current and entered date time
  if(remain < 0) 
  {
   clearInterval(timer);
   tourstarted=true;
   setendtimer(tourtime);
   return;
  }
  var days = Math.floor(remain / day); // Get Remaining Days
  var hours = Math.floor((remain % day) / hour); // Get Remaining Hours
  var minutes = Math.floor((remain % hour) / minute); // Get Remaining Min
  var seconds = Math.floor((remain % minute) / second); // Get Remaining Sec
 document.getElementById("timer_value").innerHTML = 'STARTING IN '
  if(days>0)
  document.getElementById("timer_value").innerHTML ='STARTING IN' + days + 'Days ';
  if(hours>0){
  document.getElementById("timer_value").innerHTML += hours + ':';
  }
  document.getElementById("timer_value").innerHTML += minutes;
  if(minutes<60){
  if(seconds<10)
  seconds='0'+seconds;
  document.getElementById("timer_value").innerHTML += ':' +seconds;
  }
  }
   timer = setInterval(showtimer, 1000); // Display Timer In Every 1 Sec
 }


var endtimer;
function setendtimer(tour)
{
 clearInterval(endtimer);
 var end = tour.end // Arrange values in Date Time Format
 var second = 1000; // Total Millisecond In One Sec
 var minute = second * 60; // Total Sec In One Min
 var hour = minute * 60; // Total Min In One Hour
 var day = hour * 24; // Total Hour In One Day

 function showendtimer() {
  var now = new Date().getTime();
  var remain = end - now; // Get The Difference Between Current and entered date time
  if(remain < 0) 
  {
   clearInterval(endtimer);
   tourended=true;
    $join.hide();
    $leave.hide();
   document.getElementById("timer_value").innerHTML = "Tournament Ended"
   return;
  }
  $leave.html('Pause'); 
  var hours = Math.floor((remain % day) / hour); // Get Remaining Hours
  var minutes = Math.floor((remain % hour) / minute); // Get Remaining Min
  var seconds = Math.floor((remain % minute) / second); // Get Remaining Sec
  document.getElementById("timer_value").innerHTML = "Tournament Ends In " ;
  if(hours>0){
  document.getElementById("timer_value").innerHTML += hours +':';
  } else 
  if(seconds<10)
  seconds='0'+seconds;
  document.getElementById("timer_value").innerHTML += minutes;
  document.getElementById("timer_value").innerHTML +=':'+ seconds;
 }
 endtimer = setInterval(showendtimer, 1000); // Display Timer In Every 1 Sec
}
})