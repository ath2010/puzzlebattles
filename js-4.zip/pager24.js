let jsp_current_page_score = 1;
const pagecount = 100;
let userscores =[];


function renderUserList(userList,sortBy) {
     jsp_json_object =userList.sort(sortByProperty(sortBy));
	 if(userList.length<1){
    const listing_table = document.getElementById('userscore1');
    const page_span = document.getElementById('pcount1');
     listing_table.innerHTML = '';
      page_span.innerHTML = '0';
	const btn_prev = document.getElementById('btn-prev1');
    const btn_next = document.getElementById('btn-next1');
	 btn_prev.style.display =  'none' 
    btn_next.style.display =  'none';
	 } else{
        jsp_change_page_sort(jsp_current_page_score);
	 }
}


function num_pages() {
    return Math.ceil(userscores.length / jsp_records_per_page);
}

function prev_pages() {
    if (jsp_current_page_score > 1) {
        jsp_current_page_score--;
        jsp_change_page_sort(jsp_current_page_score);
    }
}


function next_page() {
    if (jsp_current_page_score < num_pages()) {
        jsp_current_page_score++;
        jsp_change_page_sort(jsp_current_page_score);
    }
}
function jsp_change_page_sort(page) {
    const btn_prev = document.getElementById('btn-prev1');
    const btn_next = document.getElementById('btn-next1');
    const listing_table = document.getElementById('userscore1');
    let page_span = document.getElementById('pcount1');
 
    if (page < 1) {
        page = 1;
    }
    if (page > num_pages()) {
        page = num_pages();
    }

    listing_table.innerHTML = '';

    for (let i = (page - 1) * pagecount; i < (page * pagecount) && i < jsp_json_object.length; i++) {
        listing_table.innerHTML += "username" in jsp_json_object[i] ?jsp_json_object[i].username:jsp_json_object[i] +' '+ "rating" in jsp_json_object[i]? sp_json_object[i].rating:""+ "score" in jsp_json_object[i]?jsp_json_object[i].score:"" +'<br>';
    }

	var pg= (page === 1) ? ("1-"+ ((jsp_json_object.length<pagecount)?jsp_json_object.length : (page*pagecount) )+"/"+jsp_json_object.length ) : ( ((page-1)*pagecount) + 1 + "-" +(page*pagecount)+"/"+jsp_json_object.length );
    page_span.innerHTML = pg;
    btn_prev.style.display = (page === 1) ? 'none' : 'inline-block';
    btn_next.style.display = (page === num_pages()) ? 'none' : 'inline-block';
}

function sortByProperty(property){  
   return function(a,b){  
      if(a[property] < b[property])  
         return 1;  
      else if(a[property] > b[property])  
         return -1;  
  
      return 0;  
   }  

   window.onload = () => {
    document.getElementById('btn-prev1').addEventListener('click', (e) => {
        e.preventDefault();
        prev_page();
    });

    document.getElementById('btn-next1').addEventListener('click', (e) => {
        e.preventDefault();
        next_page();
    });
};
}