<?php require __DIR__ . '/wp-load.php';	 
global $wpdb;
$type= $_POST['key'];
$sql = "select distinct username,points,completeion_date from wp_puzzlereport where DATE_ADD(completeion_date, INTERVAL 5 HOUR)>CURRENT_DATE() order by points desc";

$result = $wpdb->get_results($sql);
$data = array();
foreach ($result as $row) {
	$data[] = $row;
}
echo json_encode($data);
?>

