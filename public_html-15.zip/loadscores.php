<?php require __DIR__ . '/wp-load.php';	 
global $wpdb;
$type= $_POST['key'];
$sql = "select distinct username,points,completeion_date from wp_puzzlereport where completeion_date>CURRENT_DATE() order by points desc limit 10";

if($type=='W'){
$sql = "select distinct username,points,completeion_date from wp_puzzlereport where YEARWEEK(completeion_date) = YEARWEEK(NOW()) order by points desc limit 10";
}

if($type=='M'){
$sql = "select distinct username,points,completeion_date from wp_puzzlereport where MONTH(completeion_date) = MONTH(NOW()) order by points desc limit 10";
}
$result = $wpdb->get_results($sql);
$data = array();
foreach ($result as $row) {
	$data[] = $row;
}
echo json_encode($data);
?>