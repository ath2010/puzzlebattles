<?php require __DIR__ . '/wp-load.php';
global $wpdb;

  $id = $_POST['key'];
     $points = $_POST['score'];
     $table_name = wp_puzzlereport;  

	 $wpdb->insert(
            $table_name, 
			array(
			'username' => $id,
     	   'points' => $points),array( '%s','%d'));
echo json_encode($id);
?>	

