<?php require __DIR__ . '/wp-load.php';	 
global $wpdb;
$type= $_POST['key'];
$sql = "select distinct username,points,DATE_ADD(DATE_ADD(completeion_date, INTERVAL 5 HOUR), INTERVAL 30 MINUTE) as date from wp_puzzlereport where DATE_ADD(completeion_date, INTERVAL 5 HOUR)>DATE_ADD(CURRENT_DATE(), INTERVAL 5 HOUR) order by points desc";

$result = $wpdb->get_results($sql);
$data = array();
foreach ($result as $row) {
	$data[] = $row;
}
echo json_encode($data);
?>


