<?php require __DIR__ . '/wp-load.php';	 
global $wpdb;
$rating= $_POST['rating'];
$sql = "SELECT FEN,Moves,Rating FROM lichess_puzzles ORDER BY RAND() LIMIT 1";

if($rating>50) {
$sql = "SELECT FEN,Moves,Rating FROM puzzles where (Rating>2000) ORDER BY RAND() LIMIT 1";
}

$result = $wpdb->get_results($sql);
$data = array();
foreach ($result as $row) {
	$data[] = $row;
}
echo json_encode($data);
?>