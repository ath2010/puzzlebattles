<html lang="en">
<head>
</head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Bootstrap 4 Bordered Table</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<style type="text/css">
.bs-example{
margin: 20px;
}
</style>
</head>
<body>
<div class="bs-example">
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="page-header clearfix">
<h2 class="pull-left">Learn My Skills Todays Top 10 Puzzle Solvers</h2>
<?php require __DIR__ . '/wp-load.php';	 
global $wpdb;
$sql = "SELECT username,points from wp_puzzlereport where completeion_date>DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 5 HOUR) order by points limit 10";
$result = $wpdb->get_results($sql);
?>
<table class='table table-bordered table-striped'>
<tr>
<td>User Name</td>
<td>Points </td>
</tr>
<?php
foreach ($result as $row) {
?>
<tr>
<td>user </td>
<td><?php echo $row["username"]; ?></td>
</tr>
</table>
<?php
}
?>
</div>

</div>
</div>        
</div>
</div>
</body>
</html>