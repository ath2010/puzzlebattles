positions = [];
var currPos=0;
var currMov=0;
name="";
pzsolved=0;
var starttime=null;
$(function() {
    console.log( "ready!" );
	name = localStorage.getItem("user");
	starttime=localStorage.getItem("starttime");
	if (starttime!==null)
	{
     pzsolved = localStorage.getItem("pzsolved");
     } 
     console.log(pzsolved);


   
});

function loadPuzzles(){
	if (name!==null && name!==""&& name!=="undefined")
	{
		{
            $.post("loadpz.php",
                function (data)
                {
				var jdata=JSON.parse(data);
				
    for (var i = 0; i < jdata.length; i++) {
		if(jdata[i].moves!==null){	
       var moves =jdata[i].Moves.split(" ");
	   positions.push({fen:jdata[i].FEN,moves:moves});
		}
    }
     ChessgroundExamples.run(document.getElementById('chessground-examples'));	 
	});
   }
}
}

$(window).on('beforeunload', function () {
	 console.log("beforeunload");	
     localStorage.setItem("name", user);
})



function calScore(){
  $('#status').html(" Great . You have solved the Puzzle"); 
  $('#score').html("Puzzle Solved: "+pzsolved.length);
  }

function getCurrentTime(){
 return new Date().getTime();
}

function puzzleclock(){
var deadline = new Date(starttime).getTime();
var x = setInterval(function() {
 var now = new Date().getTime();
var t = deadline - now;
var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
var seconds = Math.floor((t % (1000 * 60)) / 1000);
document.getElementById("minute").innerHTML = minutes; 
document.getElementById("second").innerHTML =":"+seconds; 
if (t < 0) {
        clearInterval(x);
        document.getElementById("minute").innerHTML ="TIME" ; 
        document.getElementById("second").innerHTML = "UP"; }
}, 1000);


}