positions = [];
var currPos=0;
var currMov=0;
dpzsolved=null;
var dendTime=null;
rating=1;
$(function() {
 socket = io("https://puzzlebattles.herokuapp.com");    
    console.log( "ready!" );
	currentRushTimer();
     var start = document.getElementById('start');
	   if(start!==null){
     start.parentNode.removeChild(start);
	   }
	dendTime=localStorage.getItem("dendTime");
	console.log(dendTime);
	if (dendTime!==null && dendTime!=="DEXPIRED")
	{	
   loadControlButtons();
	 puzzleclock();
	 loadPuzzles();
     dpzsolved = localStorage.getItem("dpzsolved");
	 console.log(dpzsolved);
	 if(dpzsolved !==null){
	  $('#score').html("Puzzles Solved: "+ dpzsolved.length);
	 }
	
    } else{
	if (localStorage.getItem("loginname")===null)
	{
     console.log("username not found");

	} else {
if(localStorage.getItem("loginname")!==null &&  localStorage.getItem("start")==='start'){
var user=localStorage.getItem("loginname");
$('#usermsg').html("Welcome,"+user +"Puzzle rush will start now") ;
setTimeout(function(){ 
  startPuzzle();
},2000);
} else{
 $('#usermsg').html("<a class='text fbt strong glowing' href='https://www.learnmyskills.com/puzzlerush'>Back to tournament page</a>");

}
localStorage.removeItem("dpzsolved");
}
	}
});


function loadControlButtons(){
  var next = document.getElementById('next');
   var end = document.getElementById('end');
 
   if(next===null){
   var new_btn = $('<button class="btn btn-success title="Next Puzzle Rush" id="next"  onclick="nextPuzzle()">Load Next Puzzle</button> ');         
     new_btn.insertAfter('#usermsg');      
   }
    if(end===null){
   var new_btn = $('<button class="btn btn-danger" title="End Puzzle Rush" id="end" onclick="endPuzzle()">End Puzzle Rush</button>');         
     new_btn.insertAfter('#next');      
   }
     console.log(next);
}



function startPuzzle(){
 
   var minsToAdd=15;
   dpzsolved="";
   dendTime=getCurrentTime()+minsToAdd * 60000;
    localStorage.setItem("dendTime",dendTime);
    localStorage.setItem("dpzsolved",dpzsolved);
   $('#usermsg').html(" ");
   nextPuzzle();
 
}

function endPuzzle(){
	  $('#usermsg').html("Puzzle Rush ended");
	  if(dpzsolved!==null){
	  $('#score').html("Puzzles Solved: "+ dpzsolved.length);
       postReport(dpzsolved.length);
	  }

	    dendTime="DEXPIRED";
	    localStorage.removeItem("dendTime");
		localStorage.removeItem("dpzsolved");
		localStorage.removeItem("start");
	   document.getElementById("time").innerHTML ="" ; 
	    $('#usermsg').html("<a class='text fbt strong glowing' href='https://www.learnmyskills.com/puzzlerush'>Back to tournament page</a>");
	   var end = document.getElementById('end');
        end.parentNode.removeChild(end);
		 var next = document.getElementById('next');
        next.parentNode.removeChild(next);
}

function nextPuzzle(){
 localStorage.setItem("dpzsolved",dpzsolved);
  rating=dpzsolved.length;
   location.reload(true);
}

function loadPuzzles(){
	
		{
            $.post("loadpz.php",{key: rating},
                function (data)
                {
var jdata=JSON.parse(data);	
    for (var i = 0; i < jdata.length; i++) {
		if(jdata[i].moves!==null){	
       var moves =jdata[i].Moves.split(" ");
	   positions.push({fen:jdata[i].FEN,moves:moves});
		 console.log(jdata[i].Rating);
		}
    }
     ChessgroundExamples.run(document.getElementById('chessground-examples'));	 
	});
   }
}


function getCurrentTime(){
 return new Date().getTime();
}

function puzzleclock(){

var x = setInterval(function() {
		if(dendTime!=="DEXPIRED"){
 var now = new Date().getTime();
var t = dendTime - now;
var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
var seconds = Math.floor((t % (1000 * 60)) / 1000);
document.getElementById("time").innerHTML = minutes+":"+seconds;  


if (t < 0 ) {
        clearInterval(x);
		localStorage.setItem("dendTime","DEXPIRED");
		endPuzzle();
        document.getElementById("time").innerHTML ="TIME UP" ; 
        } }
		}, 1000);
}


function postReport(score1) {
	{
      console.log(score1);
      var user1=localStorage.getItem("loginname");
	  socket.emit('user attempted',user1);
	 localStorage.setItem('attempted','attempted');
                $.post("puzzlerepot.php",{key: user1,score: score1},
                function (data)
                {
		
				console.log(data);
				 
}
				
  	);
	 //  socket.emit('add user',{'username':loginuser,'score':score1});
   }
}

   function currentRushTimer(){
  // The data/time we want to countdown to
	if((new Date().getUTCHours()>=12 && new Date().getUTCMinutes()>=30)|| new Date().getUTCHours()>13 ){
    var endHour=new Date().setUTCHours(15);
	var endMin= new Date(endHour).setUTCMinutes(30);
    var countDownDate =endMin ;
    // Run currrush every second
    var currrush = setInterval(function() {

    var now = new Date().getTime();
    var timeleft = countDownDate - now;
        
    // Calculating the days, hours, minutes and seconds left
    var days = Math.floor(timeleft / (1000 * 60 * 60 * 24));
    var hours = Math.floor((timeleft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((timeleft % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((timeleft % (1000 * 60)) / 1000);
        
    // Result is output to the specific element
   // document.getElementById("days").innerHTML = days + "d "
    document.getElementById("currentRush").innerHTML ="Prize Money Puzzle Rush will end in " + hours + "h " + minutes + "m "  + seconds + "s " 
      
    // Display the message when countdown is over
    if (timeleft < 0) {
        clearInterval(currrush);
        document.getElementById("currentRush").innerHTML  = "TIME UP!!";
    }
    }, 1000);
	} 
   }

Date.prototype.addDays = function(days) {
    var date = new Date(this.valueOf());
    date.setDate(date.getDate() + days);
    return date;
}


   