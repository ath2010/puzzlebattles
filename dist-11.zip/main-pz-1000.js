positions = [];
var currPos=0;
var currMov=0;
pzsolved=null;
var endTime=null;
rating=1;
$(function() {
    console.log( "ready!" );
	currentRushTimer();
	endTime=localStorage.getItem("endTime");
	console.log(endTime);
	if (endTime!==null && endTime!=="EXPIRED")
	{	
     loadPuzzles();
	 puzzleclock();

     var start = document.getElementById('start');
	   if(start!==null){
     start.parentNode.removeChild(start);
	   }
     pzsolved = localStorage.getItem("pzsolved");
	 console.log(pzsolved);
	 loadControlButtons();
	 if(pzsolved !==null){
	  $('#score').html("Puzzles Solved: "+ pzsolved.length);
	 }
	
    } else{
	if (localStorage.getItem("loginname")===null)
	{

	} else {
	 

	localStorage.removeItem("pzsolved");
     document.getElementById("usermsg").innerHTML ="Please click on start for New Rush"
	    var start = document.getElementById('start');

    if(start===null){
     var new_btn = $('<button class="btn btn-success" title="start Puzzle Rush" id="start" onclick="startPuzzle()">Start</button>');         
     new_btn.insertAfter('#strt');      
   }
}
	}
});


function loadControlButtons(){
  var next = document.getElementById('next');
   var end = document.getElementById('end');
   if(next===null){
   var new_btn = $('<button class="btn btn-success title="Next Puzzle Rush" id="next"  onclick="nextPuzzle()">Load Next Puzzle</button> ');         
     new_btn.insertAfter('#strt');      
   }
    if(end===null){
   var new_btn = $('<button class="btn btn-danger" title="End Puzzle Rush" id="end" onclick="endPuzzle()">End Puzzle Rush</button>');         
     new_btn.insertAfter('#next');      
   }
}

function loadUserButtons(){
  var uname = document.getElementById('uname');
  console.log("uname"+uname);
   var usubmit = document.getElementById('usubmit');
    console.log("usubmit"+ usubmit);
   if(uname===null){
   var uname_btn = $(' <input type="text" id="uname" name="uname" class="form-control" value="Enter username">');         
     uname_btn.insertAfter('#strt');      
   }
    if(usubmit===null){
   var new_btn = $('<input type="submit" title="Enter a valid user and click validate to enable the Puzzle Rush" class="btn btn-primary" onclick="validateUser()"  id="usubmit"  name="usubmit" value="Validate User">');         
     new_btn.insertAfter('#strt');      
   }
}

function startPuzzle(){
   var minsToAdd=15;
   pzsolved="";
   var elem = document.getElementById('start');
   elem.parentNode.removeChild(elem);
   endTime=getCurrentTime()+minsToAdd * 60000;
    localStorage.setItem("endTime",endTime);
    localStorage.setItem("pzsolved",pzsolved);
   nextPuzzle();
}

function endPuzzle(){
	  $('#usermsg').html("Puzzle Rush ended");
	  if(pzsolved!==null){
	  $('#score').html("Puzzles Solved: "+ pzsolved.length);
       postReport(pzsolved.length);
	  }

	   endTime="EXPIRED";
	    localStorage.removeItem("endTime");
		localStorage.removeItem("pzsolved");
	   document.getElementById("time").innerHTML ="" ; 
	   var end = document.getElementById('end');
        end.parentNode.removeChild(end);
		 var next = document.getElementById('next');
        next.parentNode.removeChild(next);
		   var start = document.getElementById('start');
    if(start===null){
	     var new_btn = $('<button class="btn btn-success" title="tart Puzzle Rush" id="start" onclick="startPuzzle()">Start</button>');         
         new_btn.insertAfter('#strt');  
	}

}

function nextPuzzle(){
 localStorage.setItem("pzsolved",pzsolved);
  rating=pzsolved.length;
   location.reload(true);
}

function loadPuzzles(){
	
		{
            $.post("loadpz.php",{key: rating},
                function (data)
                {
var jdata=JSON.parse(data);	
    for (var i = 0; i < jdata.length; i++) {
		if(jdata[i].moves!==null){	
       var moves =jdata[i].Moves.split(" ");
	   positions.push({fen:jdata[i].FEN,moves:moves});
		 console.log(jdata[i].Rating);
		}
    }
     ChessgroundExamples.run(document.getElementById('chessground-examples'));	 
	});
   }
}


function getCurrentTime(){
 return new Date().getTime();
}

function puzzleclock(){

var x = setInterval(function() {
		if(endTime!=="EXPIRED"){
 var now = new Date().getTime();
var t = endTime - now;
var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
var seconds = Math.floor((t % (1000 * 60)) / 1000);
document.getElementById("time").innerHTML = minutes+":"+seconds;  


if (t < 0 ) {
        clearInterval(x);
		localStorage.setItem("endTime","EXPIRED");
		endPuzzle();
        document.getElementById("time").innerHTML ="TIME UP" ; 
        } }
		}, 1000);
}


function postReport(score1) {
	{
		console.log(score1);
		var user1=localStorage.getItem("loginname");
                $.post("puzzlerepot.php",{key: user1,score: score1},
                function (data)
                {
		
				console.log(data);
				 
}
				
  	);
   }
}

   function currentRushTimer(){
  // The data/time we want to countdown to
	if(new Date().getUTCHours()>3 || (new Date().getUTCHours()>=3 && new Date().getUTCMinutes()>=30)){
    var endHour=new Date().setUTCHours(15);
	var endMin= new Date(endHour).setUTCMinutes(30);
    var countDownDate =endMin ;
    // Run currrush every second
    var currrush = setInterval(function() {

    var now = new Date().getTime();
    var timeleft = countDownDate - now;
        
    // Calculating the days, hours, minutes and seconds left
    var days = Math.floor(timeleft / (1000 * 60 * 60 * 24));
    var hours = Math.floor((timeleft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((timeleft % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((timeleft % (1000 * 60)) / 1000);
        
    // Result is output to the specific element
   // document.getElementById("days").innerHTML = days + "d "
    document.getElementById("currentRush").innerHTML ="Prize Money Puzzle Rush will end in " + hours + "h " + minutes + "m "  + seconds + "s " 
      
    // Display the message when countdown is over
    if (timeleft < 0) {
        clearInterval(currrush);
        document.getElementById("currentRush").innerHTML  = "TIME UP!!";
    }
    }, 1000);
	} else{
	var endHour=new Date(new Date().getDate()+1).setUTCHours(3);
	var endMin= new Date(endHour).setUTCMinutes(30);
    var countDownDate =endMin ;
    // Run currrush every second
    var currrush = setInterval(function() {

    var now = new Date().getTime();
    var timeleft = countDownDate - now;
        
    // Calculating the days, hours, minutes and seconds left
    var days = Math.floor(timeleft / (1000 * 60 * 60 * 24));
    var hours = Math.floor((timeleft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((timeleft % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((timeleft % (1000 * 60)) / 1000);
        
    // Result is output to the specific element
   // document.getElementById("days").innerHTML = days + "d "
    document.getElementById("currentRush").innerHTML ="Next Prize Money Puzzle Rush will start in "+ hours + "h " + minutes + "m "  + seconds + "s " 
      
    // Display the message when countdown is over
    if (timeleft < 0) {
        clearInterval(currrush);
        document.getElementById("currentRush").innerHTML  = "Today's Puzzle Started!!";
    }
    }, 1000);
		
	}

   }

Date.prototype.addDays = function(days) {
    var date = new Date(this.valueOf());
    date.setDate(date.getDate() + days);
    return date;
}


   